﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyShop.Models
{
    public class MyRole
    {
        public static string Admin = "Admin";
        public static string Employee = "Employee";
        public static string Customer = "Customer";
        public static string Guest = "Guest";
    }
}
